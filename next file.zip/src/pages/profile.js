import { useState, useEffect } from 'react';

const Profile = () => {
  const [userData, setUserData] = useState({
    name: '',
    age: '',
    dob: '',
    contact: ''
  });

  useEffect(() => {
    // Fetch user data on load (e.g., from localStorage or API)
    const getUserData = async () => {
      const res = await fetch('/api/user/profile');
      const data = await res.json();
      setUserData(data);
    };
    getUserData();
  }, []);

  const handleChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Send updated data to API
    await fetch('/api/user/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="name"
        value={userData.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input
        type="text"
        name="age"
        value={userData.age}
        onChange={handleChange}
        placeholder="Age"
      />
      <input
        type="date"
        name="dob"
        value={userData.dob}
        onChange={handleChange}
        placeholder="Date of Birth"
      />
      <input
        type="text"
        name="contact"
        value={userData.contact}
        onChange={handleChange}
        placeholder="Contact Information"
      />
      <button type="submit">Update Profile</button>
    </form>
  );
};

export default Profile;
